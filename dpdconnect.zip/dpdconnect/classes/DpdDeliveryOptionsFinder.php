<?php

namespace DpdConnect\classes;

/**
 * This file is part of the Prestashop Shipping module of DPD Nederland B.V.
 *
 * Copyright (C) 2017  DPD Nederland B.V.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

use Configuration;
use DeliveryOptionsFinder;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;

class DpdDeliveryOptionsFinder extends DeliveryOptionsFinder
{
    public $dpdCarrier;
    public $dpdProductHelper;

    public function getDeliveryOptions()
    {
        $this->dpdCarrier = new DpdCarrier();
        $this->dpdProductHelper = new DpdProductHelper();

        $carriers_available = parent::getDeliveryOptions();

        if (!$this->dpdCarrier->checkIfSaturdayAllowed()) {
            foreach ($carriers_available as $key => $availableCarrier) {
                $availableCarrierId = str_replace(',', '', $key);

                if ($this->dpdCarrier->isSaturdayCarrier($availableCarrierId)) {
                    unset($carriers_available[$key]);
                }
            }
        }

        return $carriers_available;
    }
}
